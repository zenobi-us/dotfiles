// Libraries expect browser timers; GPUI exposes per-view native timer tasks instead.
let owner = null, serial = 0; const jobs = new Map();
function schedule(job) { job.task = owner.after(Math.max(1, job.due - Date.now()), () => { if (!jobs.has(job.id)) return; if (!job.repeat) jobs.delete(job.id); job.fn(...job.args); if (job.repeat && jobs.has(job.id)) { job.due = Date.now() + job.ms; schedule(job); } }); }
export function install(timer) { owner = timer; globalThis.setTimeout = (fn, ms = 0, ...args) => add(fn, ms, args, false); globalThis.setInterval = (fn, ms = 0, ...args) => add(fn, ms, args, true); globalThis.clearTimeout = globalThis.clearInterval = id => { jobs.get(id)?.task.cancel(); jobs.delete(id); }; }
function add(fn, ms, args, repeat) { const job = { id: ++serial, fn, ms, args, repeat, due: Date.now() + ms }; jobs.set(job.id, job); schedule(job); return job.id; }
export function transfer(timer) { owner = timer; for (const job of jobs.values()) { job.task.cancel(); schedule(job); } }
export function stop() { for (const j of jobs.values()) j.task.cancel(); jobs.clear(); owner = null; }
