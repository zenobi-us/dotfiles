// Each view holds its own receive task. A shared cursor dispatches each byte frame once.
import { exec } from 'herdr';
const base = 'http://127.0.0.1:18592';
export const record = x => fetch(base + '/log', { method: 'POST', body: JSON.stringify({ time: Date.now(), ...x }) }).catch(() => { });
export class RelaySocket {
 static CONNECTING = 0; static OPEN = 1; static CLOSING = 2; static CLOSED = 3;
 CONNECTING = 0; OPEN = 1; CLOSING = 2; CLOSED = 3;
 constructor(url) { this.readyState = 0; this.cursor = 0; this.chain = Promise.resolve(); this.opened = this.open(url); }
 async open(url) { const response = await fetch(base + '/open', { method: 'POST', body: JSON.stringify({ url }) }); this.id = (await response.json()).id; }
 async receive() { try { await this.opened; while (this.readyState !== 3) { const events = await (await fetch(base + '/events?id=' + this.id + '&after=' + this.cursor)).json(); for (const e of events) { if (e.seq <= this.cursor) continue; this.cursor = e.seq; if (e.type === 'open') { this.readyState = 1; this.onopen?.({}); } if (e.type === 'message') { record({ event: 'receipt', bytes: e.data.length }); this.onmessage?.({ data: new Uint8Array(e.data).buffer }); } if (e.type === 'error') this.onerror?.(e); if (e.type === 'close') { this.readyState = 3; this.onclose?.(e); } } } } catch (error) { record({ event: 'adapter-error', error: String(error) }); this.close(); this.readyState = 3; this.onerror?.({ error }); this.onclose?.({ code: 1006, reason: String(error) }); } }
 send(data) { const bytes = new Uint8Array(data.buffer ?? data, data.byteOffset ?? 0, data.byteLength); this.chain = this.chain.then(() => fetch(base + '/send?id=' + this.id, { method: 'POST', body: bytes })).catch(error => record({ event: 'send-error', error: String(error) })); }
 close() { if (this.readyState === 3) return; this.readyState = 2; if (this.id) this.closed = exec('curl', ['--silent', '--max-time', '1', '-X', 'POST', base + '/close?id=' + this.id]).catch(() => { }); }
}
