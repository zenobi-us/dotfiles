// One module-owned replica; each view owns its observer wait and local preference.
import { View, div } from 'gpui-kit';
import { v_flex } from 'gpui-base';
import { checking, theme, props, nextCommand } from 'herdr';
import { syncedStore, getYjsDoc } from '@syncedstore/core';
import { WebsocketProvider } from 'y-websocket';
import { RelaySocket, record } from './adapter.js';
import { install, transfer, stop } from './timers.js';
let replica = null;
function checksum(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(16); }
function acquire() {
 if (!replica) {
  const store = syncedStore({ records: {} }), doc = getYjsDoc(store);
  const r = { store, doc, views: new Set(), revision: 0, status: 'starting', synced: false, summaries: [] }; replica = r;
  r.publish = event => {
   r.revision++;
   r.summaries = Object.keys(store.records).map(id => { const x = store.records[id]; return { id, title: x.title, phase: x.phase, bodyLength: x.body?.length, checksum: x.body ? checksum(x.body) : null }; });
   record({ event, revision: r.revision, status: r.status, synced: r.synced, views: r.views.size, client: doc.clientID, records: r.summaries });
   for (const v of r.views) { v.wake?.(); v.wake = null; }
  };
  doc.on('update', () => r.publish('observer'));
  r.provider = new WebsocketProvider('ws://127.0.0.1:18591', 'checkout', doc, { WebSocketPolyfill: RelaySocket, disableBc: true });
  r.provider.on('status', e => { r.status = e.status; r.publish('status'); });
  r.provider.on('sync', s => { r.synced = s; r.publish('sync'); });
  record({ event: 'replica-created', client: doc.clientID });
 }
 return replica;
}
export default class Experiment extends View {
 init(_props, cx) {
  this.name = props()?.name ?? 'check'; this.preference = props()?.preference ?? 'compact'; if (checking()) return;
  this.timer = cx.timer; install(this.timer); this.r = acquire(); this.r.views.add(this); this.r.publish('view-open');
  cx.spawn(async cx => {
   let previous = -1;
   for (; ;) {
    const socket = this.r.provider.ws;
    if (socket && socket !== this.socket) { this.socket = socket; cx.spawn(async () => await socket.receive()); }
    if (previous !== this.r.revision) { previous = this.r.revision; cx.notify(); record({ event: 'ui-notify', name: this.name, revision: previous, preference: this.preference }); }
    await new Promise(resolve => this.wake = resolve);
   }
  });
  cx.spawn(async cx => { for (; ;) { const c = await nextCommand(); if (c === 'write') { this.r.store.records.desktop = { title: 'Forbidden desktop write' }; this.r.publish('desktop-attempt'); } record({ event: 'command', name: this.name, command: c }); cx.notify(); } });
 }
 async close() { if (!this.r) return; this.r.views.delete(this); this.r.publish('view-close'); if (!this.r.views.size) { this.r.provider.destroy(); this.r.doc.destroy(); stop(); replica = null; await record({ event: 'replica-destroyed' }); } else transfer([...this.r.views][0].timer); }
 render() { const t = theme(), r = this.r; return v_flex().size_full().bg(t.surface).text_color(t.foreground).p(24).gap(12).child(div().text_size(24).child('SyncedStore inside GPUI')).child(div().child('Copy ' + this.name + ' · preference ' + this.preference)).child(div().child(r ? 'status ' + r.status + ' · synced ' + r.synced + ' · observers ' + r.revision + ' · copies ' + r.views.size : 'Check: real libraries loaded')).children(r ? r.summaries.map(x => div().child(x.id + ': ' + x.title + ' [' + (x.phase ?? '') + ']' + (x.bodyLength ? ' length ' + x.bodyLength + ' checksum ' + x.checksum : ''))) : []); }
}
