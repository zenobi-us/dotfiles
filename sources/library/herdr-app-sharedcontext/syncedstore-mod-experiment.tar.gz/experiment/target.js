// Authoritative test target: desktop document updates are rejected before Yjs sees them.
import { syncedStore, getYjsDoc } from '@syncedstore/core';
import * as Y from 'yjs';
import * as enc from 'lib0/encoding';
import * as dec from 'lib0/decoding';
import * as sync from 'y-protocols/sync';
import { WebSocketServer } from 'ws';
import { appendFileSync } from 'node:fs';
const log = x => appendFileSync('target.jsonl', JSON.stringify({ time: Date.now(), ...x }) + '\n');
const store = syncedStore({ records: {} }), doc = getYjsDoc(store);
store.records.initial = { title: 'Initial target record', phase: 'initial' };
let offline = false, rejected = 0;
const wss = new WebSocketServer({ port: 18591, host: '127.0.0.1' });
function frame(update) { const e = enc.createEncoder(); enc.writeVarUint(e, 0); sync.writeUpdate(e, update); return enc.toUint8Array(e); }
doc.on('update', u => { log({ event: 'publication', bytes: u.length, keys: Object.keys(store.records) }); for (const c of wss.clients) if (c.readyState === 1) c.send(frame(u)); });
wss.on('connection', ws => { if (offline) { ws.close(); return; } log({ event: 'connection' }); ws.on('message', data => { const d = dec.createDecoder(new Uint8Array(data)); const type = dec.readVarUint(d); if (type !== 0) return; const sub = dec.readVarUint(d); if (sub !== 0) { rejected++; log({ event: 'rejected', sub, bytes: data.length }); return; } const e = enc.createEncoder(); enc.writeVarUint(e, 0); sync.readSyncStep1(d, e, doc); ws.send(enc.toUint8Array(e)); }); });
Bun.serve({ port: 18593, hostname: '127.0.0.1', async fetch(req) { const url = new URL(req.url); if (url.pathname === '/state') return Response.json({ records: JSON.parse(JSON.stringify(store.records)), rejected, clients: wss.clients.size, offline }); const a = await req.json(); if (a.action === 'offline') { offline = a.value; for (const c of wss.clients) c.close(); } else if (a.action === 'set') { store.records[a.id] = a.record; } else if (a.action === 'delete') { delete store.records[a.id]; } else if (a.action === 'large') { store.records.large = { title: 'Large binary payload', body: '世界🙂abc'.repeat(32768), phase: 'large' }; } log({ event: 'control', action: a.action, id: a.id }); return Response.json({ ok: true, time: Date.now() }); } });
log({ event: 'started', pid: process.pid }); console.log('TARGET READY 18591 18593');
