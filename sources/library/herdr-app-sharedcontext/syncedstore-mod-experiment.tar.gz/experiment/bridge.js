// Transport only: WebSocket byte/event relay. No document library or domain data.
import WebSocket from 'ws';
import { appendFileSync } from 'node:fs';
const sockets = new Map(); let serial = 0;
const log = x => appendFileSync('bridge.jsonl', JSON.stringify({ time: Date.now(), ...x }) + '\n');
function push(s, event) { s.events.push({ ...event, seq: s.events.length + 1 }); for (const wake of [...s.waiters]) wake(); }
async function hold(s, after) { if (s.events.length > after) return; await new Promise(resolve => { const finish = () => { clearTimeout(timer); s.waiters.delete(finish); resolve(); }; const timer = setTimeout(finish, 15000); s.waiters.add(finish); }); }
Bun.serve({
 port: 18592, hostname: '127.0.0.1', idleTimeout: 0, async fetch(req) {
  try {
   const u = new URL(req.url), id = u.searchParams.get('id');
   if (u.pathname === '/log') { log({ event: 'mod', ...await req.json() }); return Response.json({ ok: true }); }
   if (u.pathname === '/stats') return Response.json({ sockets: [...sockets].map(([id, s]) => ({ id, state: s.ws.readyState, queued: s.events.length })), serial });
   if (u.pathname === '/open') {
    const a = await req.json(), sid = String(++serial), ws = new WebSocket(a.url), s = { ws, events: [], waiters: new Set() }; sockets.set(sid, s);
    ws.on('open', () => push(s, { type: 'open' }));
    ws.on('message', data => { log({ event: 'receive', id: sid, bytes: data.length }); push(s, { type: 'message', data: Array.from(data) }); });
    ws.on('close', (code, reason) => push(s, { type: 'close', code, reason: reason.toString() }));
    ws.on('error', e => push(s, { type: 'error', message: e.message }));
    log({ event: 'open', id: sid }); return Response.json({ id: sid });
   }
   const s = sockets.get(id); if (!s) return new Response('missing socket', { status: 404 });
   if (u.pathname === '/events') { const after = Number(u.searchParams.get('after') ?? 0); await hold(s, after); return Response.json(s.events.slice(after)); }
   if (u.pathname === '/send') { const bytes = new Uint8Array(await req.arrayBuffer()); s.ws.send(bytes); log({ event: 'send', id, bytes: bytes.length }); return Response.json({ ok: true }); }
   if (u.pathname === '/close') { s.ws.close(); log({ event: 'close', id }); return Response.json({ ok: true }); }
   return new Response('unknown', { status: 404 });
  } catch (e) { log({ event: 'error', error: String(e) }); return new Response(String(e), { status: 500 }); }
 }
});
log({ event: 'started', pid: process.pid }); console.log('BRIDGE READY 18592');
